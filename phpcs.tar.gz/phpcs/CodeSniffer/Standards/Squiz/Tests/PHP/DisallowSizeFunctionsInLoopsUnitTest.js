for (var i = 0; i < permissions.length; i++) {
    // Code here.
}

var permLen = permissions.length;
for (var length = 0; i < permLen; i++) {
    // Code here.
}

var myArray = [1, 2, 3, 4];
for (var i = myArray.length; i >= 0; i--) {
    var x = i;
}
