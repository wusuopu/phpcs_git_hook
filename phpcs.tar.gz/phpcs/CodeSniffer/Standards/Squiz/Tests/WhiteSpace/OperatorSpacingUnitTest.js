

result = 1 + 2;
result = 1  + 2;
result = 1  +   2;
result = 1 +2;
result = 1+ 2;
result = 1+2;

result = 1 - 2;
result = 1  - 2;
result = 1  -   2;
result = 1 -2;
result = 1- 2;
result = 1-2;

result = 1 * 2;
result = 1  * 2;
result = 1  *   2;
result = 1 *2;
result = 1* 2;
result = 1*2;

result = 1 / 2;
result = 1  / 2;
result = 1  /   2;
result = 1 /2;
result = 1/ 2;
result = 1/2;

result = 1 % 2;
result = 1  % 2;
result = 1  %   2;
result = 1 %2;
result = 1% 2;
result = 1%2;
result = '100%';

result += 4;
result+=4;
result -= 4;
result-=4;
result /= 4;
result/=4;
result *=4;
result*=4;

$.localScroll({offset: {top: -32}});

switch (result) {
	case -1:
		break;
}

result = x?y:z;
result = x ? y : z;
